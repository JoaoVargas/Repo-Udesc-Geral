package excecoes;

public class ErroViveiroCheio extends Exception {
    ErroViveiroCheio(){
        super("Erro: Não cabe no viveiro");
    }
}
