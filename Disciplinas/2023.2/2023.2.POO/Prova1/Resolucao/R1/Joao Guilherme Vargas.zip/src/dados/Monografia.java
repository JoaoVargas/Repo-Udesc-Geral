package dados;

public class Monografia extends Item{
    public Monografia() {
        super();
        super.setTempoEmprestimo(30);
    }
}
