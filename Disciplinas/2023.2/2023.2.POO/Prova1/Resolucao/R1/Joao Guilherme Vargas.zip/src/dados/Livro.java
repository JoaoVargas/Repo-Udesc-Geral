package dados;

public class Livro extends  Item{
    public Livro() {
        super();
        super.setTempoEmprestimo(15);
    }
}
