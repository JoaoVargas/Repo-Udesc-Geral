#include "arq.h"
#include "math.h"

#ifdef DEBUG
#endif
void main(void)
{	int tamVet, i;
	info data[]={{23,"Pedro"},{32,"Maria"},{18,"Ana"},{81,"Vania"}}, tmp;
	struct descFEC *p=NULL;

	tamVet=sizeof(data)/sizeof(info);
	printf("Instanciando a fila %i \n", tamVet);
	p=cria(tamVet);

	#ifdef DEBUG
		status(p);
	#endif
	
	printf("Inserindo na fila %i \n", tamVet);
	for(i=0;i<tamVet;i++)
		insere(&data[i], p);
			 
	i= tamanhoDaFila(p);
	printf("tamanho da fila %i\n", i);
	
	#ifdef DEBUG	
		status(p);
	#else
		buscaCauda(&tmp,p);
		printf("final da fila %i %s \n", tmp.idade,tmp.nome);
	
		buscaFrente(&tmp,p);
		printf("frente da fila %i %s \n", tmp.idade,tmp.nome);
	#endif

	printf("Removendo da fila %i", tamVet);	
	for(i=0; i<round(tamVet/2);i++)
		if (remove_(&tmp,p) == FRACASSO)
			printf("erro na remocao\n");
		else
			printf("Removido da fila %i %s \n", tmp.idade,tmp.nome);
	#ifdef DEBUG	
		status(p);
	#else	
		buscaCauda(&tmp,p);
		printf("final da fila %i %s \n", tmp.idade,tmp.nome);

		buscaFrente(&tmp,p);
		printf("frente da fila %i %s \n", tmp.idade,tmp.nome);
		i= tamanhoDaFila(p);
		printf("tamanho da fila %i, tamanho do vetor %i\n", i, tamVet);
	#endif
	printf("mais uma tentativa de inserção:\n");
	if(insere(&data[0], p)==FRACASSO)
		printf("Erro na tentativa de insercao");
	//getchar();



	for(i=0; i<round(tamVet/2);i++)
		if (remove_(&tmp,p) == FRACASSO)
			printf("erro na remocao\n");
		else
			printf("Removido da fila %i %s \n", tmp.idade,tmp.nome);
	
	#ifdef DEBUG	
		status(p);
	#else	
		buscaCauda(&tmp,p);
		printf("final da fila %i %s \n", tmp.idade,tmp.nome);

		buscaFrente(&tmp,p);
		printf("frente da fila %i %s \n", tmp.idade,tmp.nome);
		i= tamanhoDaFila(p);
		printf("tamanho da fila %i, tamanho do vetor %i\n", i, tamVet);
	#endif
	printf("mais uma tentativa de remocao:\n");
	if(remove_(&tmp,p) ==FRACASSO)
		printf("Erro na tentativa de insercao");
	else
		printf("Removido da fila %i %s \n", tmp.idade,tmp.nome);
	//getchar();

	getchar();
	p=destroi(p);
}





