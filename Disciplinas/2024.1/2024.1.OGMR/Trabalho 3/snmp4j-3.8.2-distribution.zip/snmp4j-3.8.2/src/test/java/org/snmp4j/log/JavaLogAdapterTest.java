package org.snmp4j.log;

import junit.framework.TestCase;

public class JavaLogAdapterTest extends TestCase {

    static LogFactory configuredFactory = LogFactory.getLogFactory();

    @Override
    protected void setUp() throws Exception {
        LogFactory.setLogFactory(new JavaLogFactory());
        super.setUp();
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
        LogFactory.setLogFactory(configuredFactory);
    }

    public void testEffectiveLogLevel() {
        LogAdapter loggerABCD = LogFactory.getLogger("a.b.c.d");
        LogAdapter loggerAB = LogFactory.getLogger("a.b");
        loggerAB.setLogLevel(LogLevel.INFO);
        assertEquals(LogLevel.INFO, loggerABCD.getEffectiveLogLevel());
    }

    public void testLogLevel() {
        LogAdapter loggerZBC = LogFactory.getLogger("z.b.c");
        LogAdapter loggerZ = LogFactory.getLogger("z");
        assertEquals(LogLevel.NONE, loggerZBC.getLogLevel());
        loggerZ.setLogLevel(LogLevel.DEBUG);
        loggerZBC.setLogLevel(LogLevel.INFO);
        assertEquals(LogLevel.INFO, loggerZBC.getLogLevel());
        assertEquals(LogLevel.INFO, loggerZBC.getEffectiveLogLevel());
        loggerZBC.setLogLevel(LogLevel.NONE);
        assertEquals(LogLevel.DEBUG, loggerZBC.getEffectiveLogLevel());
    }

    public void testTestGetName() {
        LogAdapter loggerABCD = LogFactory.getLogger("a.b.c.d");
        assertEquals("a.b.c.d", loggerABCD.getName());
    }

}